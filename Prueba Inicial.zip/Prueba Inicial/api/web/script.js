document.addEventListener('DOMContentLoaded', function () {
	// Crear el mapa
	const map = L.map('map').setView([0, 0], 2);

	L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
		attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
	}).addTo(map);

	const eventos = [
		{
			"id": "EONET_11107",
			"title": "Wildfire in Portugal 1022225",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11107",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022225"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-16T19:00:00Z",
					"type": "Point",
					"coordinates": [-7.89007809194233, 40.8671388514953]
				}


			]
		},

		{
			"id": "EONET_11108",
			"title": "Wildfire in Portugal 1022226",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11108",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022226"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-16T19:00:00Z",
					"type": "Point",
					"coordinates": [-8.0226309995447949, 41.18858553443058]
				}


			]
		},

		{
			"id": "EONET_11138",
			"title": "Wildfire in Brazil 1022247",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11138",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022247"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-16T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.285968449228456, -8.8367675159659438]
				}


			]
		},

		{
			"id": "EONET_11139",
			"title": "Wildfire in Botswana 1022231",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11139",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022231"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-16T19:00:00Z",
					"type": "Point",
					"coordinates": [25.011589071217173, -22.845321378346188]
				}


			]
		},

		{
			"id": "EONET_11102",
			"title": "Homestead Wildfire, Sheridan, Montana",
			"description": "Near the community of Homestead",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11102",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 1000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-16T10:07:00Z",
					"type": "Point",
					"coordinates": [-104.567, 48.4803]
				}


			]
		},

		{
			"id": "EONET_11105",
			"title": "Typhoon Pulasan",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11105",
			"closed": null,
			"categories": [
				{
					"id": "severeStorms",
					"title": "Severe Storms"
				}

			],
			"sources": [
				{
					"id": "JTWC",
					"url": "https://www.metoc.navy.mil/jtwc/products/wp1524.tcw"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T00:00:00Z",
					"type": "Point",
					"coordinates": [142.7, 14.6]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T06:00:00Z",
					"type": "Point",
					"coordinates": [142, 16.2]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T12:00:00Z",
					"type": "Point",
					"coordinates": [140.9, 16.7]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T18:00:00Z",
					"type": "Point",
					"coordinates": [140.5, 17.6]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-17T00:00:00Z",
					"type": "Point",
					"coordinates": [138.7, 18.5]
				},

				{
					"magnitudeValue": 45.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-17T06:00:00Z",
					"type": "Point",
					"coordinates": [136.4, 20.4]
				},

				{
					"magnitudeValue": 60.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-17T12:00:00Z",
					"type": "Point",
					"coordinates": [134.7, 21.2]
				},

				{
					"magnitudeValue": 65.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-17T18:00:00Z",
					"type": "Point",
					"coordinates": [133.4, 22.3]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-18T00:00:00Z",
					"type": "Point",
					"coordinates": [131.9, 23.4]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-18T06:00:00Z",
					"type": "Point",
					"coordinates": [130, 24.1]
				},

				{
					"magnitudeValue": 50.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-18T12:00:00Z",
					"type": "Point",
					"coordinates": [128.5, 25.7]
				},

				{
					"magnitudeValue": 45.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-18T18:00:00Z",
					"type": "Point",
					"coordinates": [127.8, 27]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-19T00:00:00Z",
					"type": "Point",
					"coordinates": [126.1, 28.7]
				}


			]
		},

		{
			"id": "EONET_11140",
			"title": "Wildfire in Portugal 1022232",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11140",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022232"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-15T19:00:00Z",
					"type": "Point",
					"coordinates": [-7.6690542511343356, 40.644928185733363]
				}


			]
		},

		{
			"id": "EONET_11141",
			"title": "Wildfire in Portugal 1022233",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11141",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022233"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-15T19:00:00Z",
					"type": "Point",
					"coordinates": [-7.9261055509025038, 40.4507847456896]
				}


			]
		},

		{
			"id": "EONET_11142",
			"title": "Wildfire in Namibia 1022234",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11142",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022234"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-15T19:00:00Z",
					"type": "Point",
					"coordinates": [20.199198308376953, -19.179845716748748]
				}


			]
		},

		{
			"id": "EONET_11143",
			"title": "Wildfire in Brazil 1022248",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11143",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022248"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-15T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.081830338033228, -11.034467840429857]
				}


			]
		},

		{
			"id": "EONET_11144",
			"title": "Wildfire in Portugal 1022250",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11144",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022250"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-15T19:00:00Z",
					"type": "Point",
					"coordinates": [-8.0391464820383121, 41.067261152003276]
				}


			]
		},

		{
			"id": "EONET_11109",
			"title": "Wildfire in Portugal 1022227",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11109",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022227"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-14T19:00:00Z",
					"type": "Point",
					"coordinates": [-8.4163579452839716, 40.700643093573817]
				}


			]
		},

		{
			"id": "EONET_11110",
			"title": "Wildfire in Zimbabwe 1022206",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11110",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022206"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-14T19:00:00Z",
					"type": "Point",
					"coordinates": [32.760048101354421, -19.9750248917823]
				}


			]
		},

		{
			"id": "EONET_11111",
			"title": "Wildfire in Botswana 1022207",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11111",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022207"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-14T19:00:00Z",
					"type": "Point",
					"coordinates": [21.833854707283862, -18.553052097029749]
				}


			]
		},

		{
			"id": "EONET_11112",
			"title": "Wildfire in Bolivia 1022222",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11112",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022222"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-14T19:00:00Z",
					"type": "Point",
					"coordinates": [-65.298693960242616, -11.719603154163636]
				}


			]
		},

		{
			"id": "EONET_11145",
			"title": "Wildfire in Ukraine, Russian Federation 1022230",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11145",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022230"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-14T19:00:00Z",
					"type": "Point",
					"coordinates": [39.624686317172433, 48.675654340791837]
				}


			]
		},

		{
			"id": "EONET_11059",
			"title": "Wildfire in Brazil 1022172",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11059",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022172"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.869278017692992, -11.824796687881838]
				}


			]
		},

		{
			"id": "EONET_11060",
			"title": "Wildfire in Australia 1022173",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11060",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022173"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [127.38581075652212, -18.555261023661096]
				}


			]
		},

		{
			"id": "EONET_11079",
			"title": "Wildfire in Australia 1022188",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11079",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022188"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [128.11036909306816, -17.352095306394563]
				}


			]
		},

		{
			"id": "EONET_11080",
			"title": "Wildfire in Brazil 1022195",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11080",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022195"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.674740396987652, -9.71001346986095]
				}


			]
		},

		{
			"id": "EONET_11113",
			"title": "Wildfire in Brazil 1022223",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11113",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022223"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [-52.239058586337144, -7.0252387159476708]
				}


			]
		},

		{
			"id": "EONET_11114",
			"title": "Wildfire in Namibia 1022209",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11114",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022209"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [19.802339517802217, -19.195386870040732]
				}


			]
		},

		{
			"id": "EONET_11115",
			"title": "Wildfire in Zambia 1022208",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11115",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022208"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [30.742986931058521, -9.2428980585024476]
				}


			]
		},

		{
			"id": "EONET_11116",
			"title": "Wildfire in Zambia 1022210",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11116",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022210"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [23.26505512599168, -17.284139849107206]
				}


			]
		},

		{
			"id": "EONET_11117",
			"title": "Wildfire in Tanzania 1022199",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11117",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022199"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [36.100484093988392, -3.8326274739496378]
				}


			]
		},

		{
			"id": "EONET_11146",
			"title": "Wildfire in Zambia 1022236",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11146",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022236"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [31.55477186270031, -13.010194212051594]
				}


			]
		},

		{
			"id": "EONET_11147",
			"title": "Wildfire in Portugal 1022251",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11147",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022251"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [-8.4334129124431314, 41.100932379325769]
				}


			]
		},

		{
			"id": "EONET_11148",
			"title": "Wildfire in Brazil 1022249",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11148",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022249"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [-53.226153420046728, -12.572996409430552]
				}


			]
		},

		{
			"id": "EONET_11149",
			"title": "Wildfire in Portugal 1022235",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11149",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022235"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [-7.8975570843703213, 41.550320254117928]
				}


			]
		},

		{
			"id": "EONET_11150",
			"title": "Wildfire in The Democratic Republic of Congo 1022237",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11150",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022237"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-13T19:00:00Z",
					"type": "Point",
					"coordinates": [30.202812759128445, -7.7765027931661477]
				}


			]
		},

		{
			"id": "EONET_11104",
			"title": "Manderson Wildfire, Oglala Lakota, South Dakota",
			"description": "7 Miles North of Manderson, 1/2 mile East on Gooseneck Road (BIA33)",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11104",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 2000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-13T17:26:00Z",
					"type": "Point",
					"coordinates": [-102.4622222, 43.3519444]
				}


			]
		},

		{
			"id": "EONET_11027",
			"title": "Tropical Storm Gordon",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11027",
			"closed": null,
			"categories": [
				{
					"id": "severeStorms",
					"title": "Severe Storms"
				}

			],
			"sources": [
				{
					"id": "NOAA_NHC",
					"url": "https://www.nhc.noaa.gov/archive/2024/GORDON.shtml"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T15:00:00Z",
					"type": "Point",
					"coordinates": [-38.6, 19.4]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T21:00:00Z",
					"type": "Point",
					"coordinates": [-39.5, 19.5]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T03:00:00Z",
					"type": "Point",
					"coordinates": [-40.3, 19.8]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T06:00:00Z",
					"type": "Point",
					"coordinates": [-40.9, 20.1]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T15:00:00Z",
					"type": "Point",
					"coordinates": [-41.7, 20.1]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T21:00:00Z",
					"type": "Point",
					"coordinates": [-42.9, 20.3]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T03:00:00Z",
					"type": "Point",
					"coordinates": [-43.8, 19.7]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T09:00:00Z",
					"type": "Point",
					"coordinates": [-44.8, 19.6]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T15:00:00Z",
					"type": "Point",
					"coordinates": [-45.5, 19.2]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T21:00:00Z",
					"type": "Point",
					"coordinates": [-46.1, 19.2]
				},

				{
					"magnitudeValue": 25.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T03:00:00Z",
					"type": "Point",
					"coordinates": [-46.8, 19]
				},

				{
					"magnitudeValue": 25.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T09:00:00Z",
					"type": "Point",
					"coordinates": [-47.5, 19.2]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T15:00:00Z",
					"type": "Point",
					"coordinates": [-48.1, 19.1]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T21:00:00Z",
					"type": "Point",
					"coordinates": [-48.5, 19]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-17T03:00:00Z",
					"type": "Point",
					"coordinates": [-48.8, 19]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-17T09:00:00Z",
					"type": "Point",
					"coordinates": [-49, 19]
				},

				{
					"magnitudeValue": 25.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-17T15:00:00Z",
					"type": "Point",
					"coordinates": [-49.1, 19.5]
				}


			]
		},

		{
			"id": "EONET_11103",
			"title": "La Bonte Wildfire, Converse, Wyoming",
			"description": "20 miles south of Douglas",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11103",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 3500.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-13T10:01:00Z",
					"type": "Point",
					"coordinates": [-105.527833, 42.4295]
				}


			]
		},

		{
			"id": "EONET_11021",
			"title": "Manderson Wildfire, Oglala Lakota, South Dakota",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11021",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 500.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-12T21:57:00Z",
					"type": "Point",
					"coordinates": [-102.4504253, 43.35482406]
				}


			]
		},

		{
			"id": "EONET_11028",
			"title": "Wildfire in Bolivia 1022139",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11028",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022139"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-65.327244927276411, -12.601747572965637]
				}


			]
		},

		{
			"id": "EONET_11029",
			"title": "Wildfire in Brazil 1022146",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11029",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022146"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.8804735429236, -12.378502500860527]
				}


			]
		},

		{
			"id": "EONET_11030",
			"title": "Wildfire in Brazil 1022147",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11030",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022147"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.033764909571374, -8.780011902052788]
				}


			]
		},

		{
			"id": "EONET_11061",
			"title": "Wildfire in Australia 1022166",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11061",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022166"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [131.46106224049811, -15.381740424764452]
				}


			]
		},

		{
			"id": "EONET_11062",
			"title": "Wildfire in Angola 1022171",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11062",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022171"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [17.224337208643124, -8.5937828357790629]
				}


			]
		},

		{
			"id": "EONET_11063",
			"title": "Wildfire in Bolivia 1022165",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11063",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022165"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-65.533575102981132, -13.698629378256738]
				}


			]
		},

		{
			"id": "EONET_11081",
			"title": "Wildfire in Tanzania 1022177",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11081",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022177"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [37.149205560177741, -8.4701862856632442]
				}


			]
		},

		{
			"id": "EONET_11082",
			"title": "Wildfire in Tanzania 1022178",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11082",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022178"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [34.260530437370953, -9.2811152416657485]
				}


			]
		},

		{
			"id": "EONET_11083",
			"title": "Wildfire in Namibia 1022179",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11083",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022179"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [20.191521596343826, -18.897813611577824]
				}


			]
		},

		{
			"id": "EONET_11084",
			"title": "Wildfire in Australia 1022196",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11084",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022196"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [147.46483148129883, -25.218678528060128]
				}


			]
		},

		{
			"id": "EONET_11085",
			"title": "Wildfire in Russian Federation 1022197",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11085",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022197"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [117.50913385789947, 51.179657419091839]
				}


			]
		},

		{
			"id": "EONET_11086",
			"title": "Wildfire in Brazil 1022189",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11086",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022189"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-54.255643150006286, -15.728565496252486]
				}


			]
		},

		{
			"id": "EONET_11087",
			"title": "Wildfire in Brazil 1022190",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11087",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022190"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-44.769463336997724, -21.440604712329069]
				}


			]
		},

		{
			"id": "EONET_11088",
			"title": "Wildfire in Brazil 1022191",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11088",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022191"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.539327330514389, -11.947295099115131]
				}


			]
		},

		{
			"id": "EONET_11089",
			"title": "Wildfire in Zambia 1022180",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11089",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022180"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [31.816369200801319, -10.9072680929278]
				}


			]
		},

		{
			"id": "EONET_11118",
			"title": "Wildfire in Mozambique 1022200",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11118",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022200"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [36.494606697466175, -16.910000905822486]
				}


			]
		},

		{
			"id": "EONET_11119",
			"title": "Wildfire in Mozambique 1022201",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11119",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022201"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [36.631896521547837, -16.970304788833225]
				}


			]
		},

		{
			"id": "EONET_11120",
			"title": "Wildfire in Mozambique 1022211",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11120",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022211"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [36.504502471914016, -16.917368348511655]
				}


			]
		},

		{
			"id": "EONET_11121",
			"title": "Wildfire in Angola 1022212",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11121",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022212"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [20.452907680728991, -14.718219144692311]
				}


			]
		},

		{
			"id": "EONET_11122",
			"title": "Wildfire in Brazil 1022228",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11122",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022228"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-48.118999335434246, -9.638652915290141]
				}


			]
		},

		{
			"id": "EONET_11123",
			"title": "Wildfire in Angola 1022224",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11123",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022224"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [20.447363440384294, -14.726621042049132]
				}


			]
		},

		{
			"id": "EONET_11151",
			"title": "Wildfire in Tanzania 1022238",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11151",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022238"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [31.840879015134426, -5.8235335037944633]
				}


			]
		},

		{
			"id": "EONET_11152",
			"title": "Wildfire in Zambia 1022240",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11152",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022240"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [29.735784445469967, -10.595997343751023]
				}


			]
		},

		{
			"id": "EONET_11153",
			"title": "Wildfire in Brazil 1022253",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11153",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022253"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [-58.03013457048953, -14.997236073104029]
				}


			]
		},
		{
			"id": "EONET_11154",
			"title": "Wildfire in The Democratic Republic of Congo 1022239",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11154",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022239"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [30.169238298764729, -7.5638928089477453]
				}


			]
		},

		{
			"id": "EONET_11155",
			"title": "Wildfire in Mozambique 1022241",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11155",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022241"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [37.330554784510291, -16.45745892615216]
				}


			]
		},

		{
			"id": "EONET_11156",
			"title": "Wildfire in Mozambique 1022242",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11156",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022242"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [37.831967785347437, -16.809225189483126]
				}


			]
		},

		{
			"id": "EONET_11157",
			"title": "Wildfire in Mozambique 1022243",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11157",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022243"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [38.660813757220168, -16.505258406934995]
				}


			]
		},

		{
			"id": "EONET_11158",
			"title": "Wildfire in The Democratic Republic of Congo 1022244",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11158",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022244"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-12T19:00:00Z",
					"type": "Point",
					"coordinates": [14.435756974792127, -5.3626469063089619]
				}


			]
		},

		{
			"id": "EONET_11025",
			"title": "Cedar Creek Wildfire, Sioux, North Dakota",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11025",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 500.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-12T18:29:00Z",
					"type": "Point",
					"coordinates": [-101.2336063, 46.0864627]
				}


			]
		},

		{
			"id": "EONET_10902",
			"title": "Tropical Storm Ileana",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10902",
			"closed": null,
			"categories": [
				{
					"id": "severeStorms",
					"title": "Severe Storms"
				}

			],
			"sources": [
				{
					"id": "JTWC",
					"url": "https://www.metoc.navy.mil/jtwc/products/ep0924.tcw"
				},

				{
					"id": "NOAA_NHC",
					"url": "https://www.nhc.noaa.gov/archive/2024/ILEANA.shtml"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T18:00:00Z",
					"type": "Point",
					"coordinates": [-107.7, 19.5]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T00:00:00Z",
					"type": "Point",
					"coordinates": [-108.3, 20.6]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T06:00:00Z",
					"type": "Point",
					"coordinates": [-108.7, 21.2]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T12:00:00Z",
					"type": "Point",
					"coordinates": [-109.1, 21.9]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T18:00:00Z",
					"type": "Point",
					"coordinates": [-109.2, 22.3]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T00:00:00Z",
					"type": "Point",
					"coordinates": [-109.3, 23.1]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T06:00:00Z",
					"type": "Point",
					"coordinates": [-109.2, 23.9]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T12:00:00Z",
					"type": "Point",
					"coordinates": [-109.1, 24.7]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T18:00:00Z",
					"type": "Point",
					"coordinates": [-108.9, 25.3]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T00:00:00Z",
					"type": "Point",
					"coordinates": [-109, 25.4]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T06:00:00Z",
					"type": "Point",
					"coordinates": [-109.3, 25.4]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T12:00:00Z",
					"type": "Point",
					"coordinates": [-109.5, 25.5]
				}


			]
		},

		{
			"id": "EONET_11023",
			"title": "Power Dam Road Wildfire, Mellette, South Dakota",
			"description": "1/2 mile west of White River, SD",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11023",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 10000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-12T15:05:00Z",
					"type": "Point",
					"coordinates": [-100.7616667, 43.5777778]
				}


			]
		},

		{
			"id": "EONET_11016",
			"title": "Bear Creek Wildfire, Albany, Wyoming",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11016",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 1422.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-12T14:31:00Z",
					"type": "Point",
					"coordinates": [-105.458417, 41.688278]
				}


			]
		},

		{
			"id": "EONET_10903",
			"title": "Wildfire in Brazil 1022103",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10903",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022103"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-47.863827470555826, -20.306370278972828]
				}


			]
		},

		{
			"id": "EONET_10904",
			"title": "Wildfire in Australia 1022116",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10904",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022116"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [127.48530621013363, -18.108402646144249]
				}


			]
		},

		{
			"id": "EONET_10905",
			"title": "Wildfire in Australia 1022117",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10905",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022117"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [138.93658737595197, -19.178479899888508]
				}


			]
		},

		{
			"id": "EONET_10906",
			"title": "Wildfire in Brazil 1022118",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10906",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022118"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-47.824944585797027, -20.811688661611111]
				}


			]
		},

		{
			"id": "EONET_10907",
			"title": "Wildfire in Brazil 1022119",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10907",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022119"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.577658785786895, -8.5843700001036449]
				}


			]
		},

		{
			"id": "EONET_10908",
			"title": "Wildfire in Brazil 1022012",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10908",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022012"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-49.0518889730736, -20.263230711197586]
				}


			]
		},

		{
			"id": "EONET_10909",
			"title": "Wildfire in Australia 1022013",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10909",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022013"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [127.61081848851575, -18.386477088091475]
				}


			]
		},

		{
			"id": "EONET_11031",
			"title": "Wildfire in Brazil 1022145",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11031",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022145"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-48.828823873735473, -9.5959059315374358]
				}


			]
		},

		{
			"id": "EONET_11032",
			"title": "Wildfire in Australia 1022148",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11032",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022148"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [131.81934952874772, -13.532798274655413]
				}


			]
		},

		{
			"id": "EONET_11033",
			"title": "Wildfire in Australia 1022149",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11033",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022149"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [130.59249479972186, -15.806535554731912]
				}


			]
		},

		{
			"id": "EONET_11034",
			"title": "Wildfire in Brazil 1022150",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11034",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022150"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.693814020555251, -10.944128590267155]
				}


			]
		},

		{
			"id": "EONET_11035",
			"title": "Wildfire in Australia 1022151",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11035",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022151"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [131.88839386766008, -14.12488866999124]
				}


			]
		},

		{
			"id": "EONET_11036",
			"title": "Wildfire in Australia 1022140",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11036",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022140"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [138.90098725254941, -19.096431482681947]
				}


			]
		},

		{
			"id": "EONET_11037",
			"title": "Wildfire in Brazil 1022141",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11037",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022141"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-56.225429337552157, -18.206813653119422]
				}


			]
		},

		{
			"id": "EONET_11064",
			"title": "Wildfire in Tanzania 1022157",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11064",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022157"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [34.471650142408429, -7.810573443146354]
				}


			]
		},

		{
			"id": "EONET_11065",
			"title": "Wildfire in Brazil 1022167",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11065",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022167"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.73475473121033, -11.139946058728048]
				}


			]
		},

		{
			"id": "EONET_11066",
			"title": "Wildfire in Brazil 1022174",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11066",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022174"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-62.026553184508451, -8.8166273685824219]
				}


			]
		},

		{
			"id": "EONET_11067",
			"title": "Wildfire in Brazil 1022175",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11067",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022175"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.573418081209709, -12.479726319129531]
				}


			]
		},

		{
			"id": "EONET_11068",
			"title": "Wildfire in Botswana 1022156",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11068",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022156"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [21.989526755888367, -23.245878815742273]
				}


			]
		},

		{
			"id": "EONET_11090",
			"title": "Wildfire in Botswana 1022181",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11090",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022181"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [24.064198353340529, -23.789828808162952]
				}


			]
		},

		{
			"id": "EONET_11091",
			"title": "Wildfire in Zambia 1022182",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11091",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022182"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [30.407650735443937, -9.91101848645981]
				}


			]
		},

		{
			"id": "EONET_11092",
			"title": "Wildfire in Australia 1022192",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11092",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022192"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [130.51990423013538, -15.690862047367773]
				}


			]
		},

		{
			"id": "EONET_11093",
			"title": "Wildfire in Brazil 1022193",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11093",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022193"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-46.83930117485869, -7.7552707223040924]
				}


			]
		},

		{
			"id": "EONET_11094",
			"title": "Wildfire in Australia 1022198",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11094",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022198"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [116.2476413996189, -32.6940082857453]
				}


			]
		},

		{
			"id": "EONET_11124",
			"title": "Wildfire in Bolivia 1022229",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11124",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022229"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [-64.459379877119858, -12.644689793363515]
				}


			]
		},

		{
			"id": "EONET_11125",
			"title": "Wildfire in Mozambique, Tanzania 1022213",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11125",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022213"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [36.578709487017527, -11.771667823352724]
				}


			]
		},

		{
			"id": "EONET_11126",
			"title": "Wildfire in Mozambique 1022214",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11126",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022214"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [36.766482826497267, -17.231541360280008]
				}


			]
		},

		{
			"id": "EONET_11127",
			"title": "Wildfire in Mozambique 1022215",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11127",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022215"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [38.20684975092572, -16.687934263293208]
				}


			]
		},

		{
			"id": "EONET_11128",
			"title": "Wildfire in Mozambique 1022216",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11128",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022216"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [38.837064410110308, -16.6267143180164]
				}


			]
		},

		{
			"id": "EONET_11129",
			"title": "Wildfire in Mozambique 1022203",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11129",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022203"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [38.78007784142217, -15.330771419511771]
				}


			]
		},

		{
			"id": "EONET_11130",
			"title": "Wildfire in Mozambique 1022204",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11130",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022204"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [38.332420194386984, -15.64476935257637]
				}


			]
		},

		{
			"id": "EONET_11131",
			"title": "Wildfire in Mozambique 1022217",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11131",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022217"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [33.879321135855271, -18.880663933778163]
				}


			]
		},

		{
			"id": "EONET_11132",
			"title": "Wildfire in Mozambique 1022218",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11132",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022218"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [34.86582653747228, -18.4268081503753]
				}


			]
		},

		{
			"id": "EONET_11133",
			"title": "Wildfire in Mozambique 1022202",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11133",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022202"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [33.1592768364504, -18.902433059530861]
				}


			]
		},

		{
			"id": "EONET_11159",
			"title": "Wildfire in Mozambique 1022245",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11159",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022245"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [38.108872106282696, -16.448999212598959]
				}


			]
		},

		{
			"id": "EONET_11160",
			"title": "Wildfire in Mozambique 1022246",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11160",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022246"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-11T19:00:00Z",
					"type": "Point",
					"coordinates": [37.382165797606838, -16.203666346425209]
				}


			]
		},

		{
			"id": "EONET_11024",
			"title": "Short Draw Wildfire, Campbell, Wyoming",
			"description": "30 miles North of Gillette WY",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11024",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 40000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-11T16:53:00Z",
					"type": "Point",
					"coordinates": [-105.61705, 44.955167]
				}


			]
		},

		{
			"id": "EONET_10910",
			"title": "Wildfire in Brazil 1022104",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10910",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022104"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-48.018157932334951, -20.852167708273452]
				}


			]
		},

		{
			"id": "EONET_10911",
			"title": "Wildfire in Angola 1022100",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10911",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022100"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [14.727642743486888, -15.763414438455111]
				}


			]
		},

		{
			"id": "EONET_10912",
			"title": "Wildfire in Brazil 1022120",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10912",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022120"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-57.894147530945304, -17.366336598333447]
				}


			]
		},

		{
			"id": "EONET_10913",
			"title": "Wildfire in Australia 1022121",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10913",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022121"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [135.17178175564371, -20.43362540335411]
				}


			]
		},

		{
			"id": "EONET_10914",
			"title": "Wildfire in Brazil 1022105",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10914",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022105"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-49.975003328918952, -9.703863508296223]
				}


			]
		},

		{
			"id": "EONET_10915",
			"title": "Wildfire in Brazil 1022106",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10915",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022106"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-54.857502920038065, -20.698790011367066]
				}


			]
		},

		{
			"id": "EONET_10916",
			"title": "Wildfire in Brazil 1022014",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10916",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022014"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-49.543842713327024, -9.7358992002231375]
				}


			]
		},

		{
			"id": "EONET_10917",
			"title": "Wildfire in Australia 1022015",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10917",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022015"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [133.93884334106639, -15.397523260658268]
				}


			]
		},

		{
			"id": "EONET_11038",
			"title": "Wildfire in The Democratic Republic of Congo 1022132",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11038",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022132"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [29.6582032566011, -7.6856310862104147]
				}


			]
		},

		{
			"id": "EONET_11039",
			"title": "Wildfire in Zambia 1022127",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11039",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022127"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [31.713518625966877, -10.726052616519848]
				}


			]
		},

		{
			"id": "EONET_11040",
			"title": "Wildfire in Brazil 1022125",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11040",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022125"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-44.177629833173278, -8.8568461352722263]
				}


			]
		},

		{
			"id": "EONET_11041",
			"title": "Wildfire in Brazil 1022126",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11041",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022126"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.978449199351239, -8.45586692799748]
				}


			]
		},

		{
			"id": "EONET_11069",
			"title": "Wildfire in Mozambique 1022158",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11069",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022158"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [33.147743451890079, -22.951002253434996]
				}


			]
		},

		{
			"id": "EONET_11070",
			"title": "Wildfire in Mozambique 1022159",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11070",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022159"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [37.758636712541367, -12.429366037165837]
				}


			]
		},

		{
			"id": "EONET_11071",
			"title": "Wildfire in Tanzania 1022160",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11071",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022160"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [30.85421805734147, -4.8558509496782323]
				}


			]
		},

		{
			"id": "EONET_11072",
			"title": "Wildfire in Brazil 1022168",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11072",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022168"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.130729157275567, -10.882357467757462]
				}


			]
		},

		{
			"id": "EONET_11095",
			"title": "Wildfire in Brazil 1022194",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11095",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022194"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [-55.885820613535941, -15.677864491339232]
				}


			]
		},

		{
			"id": "EONET_11096",
			"title": "Wildfire in Mozambique 1022176",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11096",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022176"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [39.840653731252594, -15.760887631397692]
				}


			]
		},

		{
			"id": "EONET_11097",
			"title": "Wildfire in Tanzania 1022183",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11097",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022183"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [31.770994719042307, -5.9754270250841621]
				}


			]
		},

		{
			"id": "EONET_11098",
			"title": "Wildfire in Mozambique 1022184",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11098",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022184"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [38.169286547524678, -16.174478714047645]
				}


			]
		},

		{
			"id": "EONET_11099",
			"title": "Wildfire in Zambia 1022185",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11099",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022185"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [31.667368502360386, -11.117271055367986]
				}


			]
		},

		{
			"id": "EONET_11134",
			"title": "Wildfire in Mozambique 1022205",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11134",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022205"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [39.140138439284264, -15.521424089293669]
				}


			]
		},

		{
			"id": "EONET_11135",
			"title": "Wildfire in Zambia 1022219",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11135",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022219"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [30.770387799692354, -8.8018127264875261]
				}


			]
		},

		{
			"id": "EONET_11136",
			"title": "Wildfire in Mozambique 1022220",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11136",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022220"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [36.758304895779162, -16.951466981202788]
				}


			]
		},

		{
			"id": "EONET_11137",
			"title": "Wildfire in Zambia 1022221",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11137",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022221"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-10T19:00:00Z",
					"type": "Point",
					"coordinates": [31.389739808758378, -12.898182546553468]
				}


			]
		},

		{
			"id": "EONET_11022",
			"title": "Point Wildfire, Maricopa, Arizona",
			"description": "Cave Creek 41 Rd/New River Wash",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11022",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 5200.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-10T18:42:00Z",
					"type": "Point",
					"coordinates": [-112.042139, 33.963917]
				}


			]
		},

		{
			"id": "EONET_10901",
			"title": "Typhoon Bebinca",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10901",
			"closed": null,
			"categories": [
				{
					"id": "severeStorms",
					"title": "Severe Storms"
				}

			],
			"sources": [
				{
					"id": "JTWC",
					"url": "https://www.metoc.navy.mil/jtwc/products/wp1424.tcw"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T18:00:00Z",
					"type": "Point",
					"coordinates": [143.9, 13.3]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T00:00:00Z",
					"type": "Point",
					"coordinates": [142.3, 13.7]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T06:00:00Z",
					"type": "Point",
					"coordinates": [141.9, 14.5]
				},

				{
					"magnitudeValue": 35.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T12:00:00Z",
					"type": "Point",
					"coordinates": [140.5, 14.8]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T18:00:00Z",
					"type": "Point",
					"coordinates": [140.1, 15.9]
				},

				{
					"magnitudeValue": 50.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T00:00:00Z",
					"type": "Point",
					"coordinates": [140, 17.4]
				},

				{
					"magnitudeValue": 60.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T06:00:00Z",
					"type": "Point",
					"coordinates": [139.7, 19.4]
				},

				{
					"magnitudeValue": 50.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T12:00:00Z",
					"type": "Point",
					"coordinates": [138.9, 21.2]
				},

				{
					"magnitudeValue": 45.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T18:00:00Z",
					"type": "Point",
					"coordinates": [137.5, 21]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T00:00:00Z",
					"type": "Point",
					"coordinates": [136.9, 22.1]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T06:00:00Z",
					"type": "Point",
					"coordinates": [135.7, 23.2]
				},

				{
					"magnitudeValue": 45.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T12:00:00Z",
					"type": "Point",
					"coordinates": [134, 24.6]
				},

				{
					"magnitudeValue": 45.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T18:00:00Z",
					"type": "Point",
					"coordinates": [132.7, 25.2]
				},

				{
					"magnitudeValue": 50.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T00:00:00Z",
					"type": "Point",
					"coordinates": [131.4, 26.3]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T06:00:00Z",
					"type": "Point",
					"coordinates": [130.3, 27.4]
				},

				{
					"magnitudeValue": 65.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T12:00:00Z",
					"type": "Point",
					"coordinates": [129.2, 28.2]
				},

				{
					"magnitudeValue": 65.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-14T18:00:00Z",
					"type": "Point",
					"coordinates": [128.2, 29]
				},

				{
					"magnitudeValue": 65.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T00:00:00Z",
					"type": "Point",
					"coordinates": [127.1, 29.7]
				},

				{
					"magnitudeValue": 75.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T06:00:00Z",
					"type": "Point",
					"coordinates": [126, 30.3]
				},

				{
					"magnitudeValue": 70.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T12:00:00Z",
					"type": "Point",
					"coordinates": [124.6, 30.5]
				},

				{
					"magnitudeValue": 70.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-15T18:00:00Z",
					"type": "Point",
					"coordinates": [123.3, 30.5]
				},

				{
					"magnitudeValue": 65.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-16T00:00:00Z",
					"type": "Point",
					"coordinates": [121.6, 30.9]
				}


			]
		},

		{
			"id": "EONET_11020",
			"title": "Siphon Wildfire, Pinal, Arizona",
			"description": "Siphon Draw and Flat Iron of Superstition Wilderness",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11020",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 12000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-10T16:42:00Z",
					"type": "Point",
					"coordinates": [-111.441367, 33.43905]
				}


			]
		},

		{
			"id": "EONET_11026",
			"title": "DRY CREEK Wildfire, Gilliam, Oregon",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11026",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 7400.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-10T11:51:00Z",
					"type": "Point",
					"coordinates": [-120.015819, 45.351261]
				}


			]
		},

		{
			"id": "EONET_10918",
			"title": "Wildfire in Angola 1022018",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10918",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022018"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [17.611234939393924, -16.76935303320321]
				}


			]
		},

		{
			"id": "EONET_10919",
			"title": "Wildfire in Bolivia 1022020",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10919",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022020"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-64.466934290801433, -14.396768210435823]
				}


			]
		},

		{
			"id": "EONET_10920",
			"title": "Wildfire in Brazil 1022016",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10920",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022016"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-48.431150064150522, -9.9859293113538481]
				}


			]
		},

		{
			"id": "EONET_10921",
			"title": "Wildfire in Brazil 1022017",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10921",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022017"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-52.656288013837425, -19.65966834815595]
				}


			]
		},

		{
			"id": "EONET_10922",
			"title": "Wildfire in Australia 1022019",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10922",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022019"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [141.86333681738066, -12.910750188705206]
				}


			]
		},

		{
			"id": "EONET_10923",
			"title": "Wildfire in Australia 1022021",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10923",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022021"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [145.39551323530242, -21.197938293623707]
				}


			]
		},

		{
			"id": "EONET_10924",
			"title": "Wildfire in United States 1022022",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10924",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022022"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-117.51567612656906, 33.667186474225311]
				}


			]
		},

		{
			"id": "EONET_10925",
			"title": "Wildfire in Brazil 1022107",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10925",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022107"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-57.5991741668039, -19.701185563629927]
				}


			]
		},

		{
			"id": "EONET_10926",
			"title": "Wildfire in Brazil 1022108",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10926",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022108"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-44.201231798218309, -8.6227419053405043]
				}


			]
		},

		{
			"id": "EONET_10927",
			"title": "Wildfire in Brazil 1022122",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10927",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022122"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.140860507879609, -14.883508675080339]
				}


			]
		},

		{
			"id": "EONET_10928",
			"title": "Wildfire in Zambia 1022101",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10928",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022101"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [31.748767311797256, -10.613349771681634]
				}


			]
		},

		{
			"id": "EONET_10929",
			"title": "Wildfire in Australia 1022113",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10929",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022113"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [145.46349680948697, -21.298716281084886]
				}


			]
		},

		{
			"id": "EONET_11042",
			"title": "Wildfire in Zambia 1022128",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11042",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022128"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [31.051050237732369, -9.7408710368084481]
				}


			]
		},

		{
			"id": "EONET_11043",
			"title": "Wildfire in Zambia 1022129",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11043",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022129"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [29.980479242770432, -10.019512180768185]
				}


			]
		},

		{
			"id": "EONET_11044",
			"title": "Wildfire in Tanzania 1022130",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11044",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022130"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [31.785942688154908, -6.1733077746558207]
				}


			]
		},

		{
			"id": "EONET_11045",
			"title": "Wildfire in Zambia 1022131",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11045",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022131"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [31.738220213861187, -10.034948865338922]
				}


			]
		},

		{
			"id": "EONET_11046",
			"title": "Wildfire in Zambia 1022133",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11046",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022133"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [31.567510376025663, -9.584774811519793]
				}


			]
		},

		{
			"id": "EONET_11047",
			"title": "Wildfire in Mozambique 1022134",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11047",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022134"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [37.509768429254024, -12.114117562382713]
				}


			]
		},

		{
			"id": "EONET_11048",
			"title": "Wildfire in Brazil 1022142",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11048",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022142"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-46.943840215567818, -21.436503225908393]
				}


			]
		},

		{
			"id": "EONET_11049",
			"title": "Wildfire in Brazil 1022152",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11049",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022152"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-55.88629756806268, -15.020656619200127]
				}


			]
		},

		{
			"id": "EONET_11050",
			"title": "Wildfire in Colombia 1022153",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11050",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022153"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-75.382562749644009, 2.8114489706090677]
				}


			]
		},

		{
			"id": "EONET_11073",
			"title": "Wildfire in Brazil 1022170",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11073",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022170"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-46.269404085292, -11.244770227031252]
				}


			]
		},

		{
			"id": "EONET_11074",
			"title": "Wildfire in Zambia 1022162",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11074",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022162"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [23.161931011044786, -17.214922558497914]
				}


			]
		},

		{
			"id": "EONET_11075",
			"title": "Wildfire in Brazil 1022161",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11075",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022161"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-49.9602812128113, -6.3916951129839106]
				}


			]
		},

		{
			"id": "EONET_11076",
			"title": "Wildfire in Brazil 1022169",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11076",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022169"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [-47.666046456072742, -7.0432976934515876]
				}


			]
		},

		{
			"id": "EONET_11100",
			"title": "Wildfire in Mozambique 1022186",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11100",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022186"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [36.665792789797706, -17.122829189416812]
				}


			]
		},

		{
			"id": "EONET_11101",
			"title": "Wildfire in Tanzania 1022187",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11101",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022187"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-09T19:00:00Z",
					"type": "Point",
					"coordinates": [35.2012148129427, -10.569536759425583]
				}


			]
		},

		{
			"id": "EONET_10892",
			"title": "WEST WARM SPRINGS Wildfire, Hot Springs, Wyoming",
			"description": "5 miles SE of Thermopolis, WY",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10892",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 2000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-09T18:41:00Z",
					"type": "Point",
					"coordinates": [-108.11155, 43.607883]
				}


			]
		},

		{
			"id": "EONET_10891",
			"title": "AIRPORT Wildfire, Orange, California",
			"description": "Trabuco Canyon",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10891",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 1900.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-09T16:24:00Z",
					"type": "Point",
					"coordinates": [-117.5816667, 33.6625]
				}


			]
		},

		{
			"id": "EONET_10885",
			"title": "Tropical Storm Francine",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10885",
			"closed": null,
			"categories": [
				{
					"id": "severeStorms",
					"title": "Severe Storms"
				}

			],
			"sources": [
				{
					"id": "NOAA_NHC",
					"url": "https://www.nhc.noaa.gov/archive/2024/FRANCINE.shtml"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 45.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-09T15:00:00Z",
					"type": "Point",
					"coordinates": [-94.9, 23]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-09T21:00:00Z",
					"type": "Point",
					"coordinates": [-96, 24]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T03:00:00Z",
					"type": "Point",
					"coordinates": [-96.2, 24.3]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T09:00:00Z",
					"type": "Point",
					"coordinates": [-96.2, 24.4]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T15:00:00Z",
					"type": "Point",
					"coordinates": [-95.6, 24.9]
				},

				{
					"magnitudeValue": 55.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T21:00:00Z",
					"type": "Point",
					"coordinates": [-95, 25.7]
				},

				{
					"magnitudeValue": 65.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T03:00:00Z",
					"type": "Point",
					"coordinates": [-94.3, 26.4]
				},

				{
					"magnitudeValue": 80.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T09:00:00Z",
					"type": "Point",
					"coordinates": [-93.8, 27]
				},

				{
					"magnitudeValue": 80.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T15:00:00Z",
					"type": "Point",
					"coordinates": [-92.7, 28]
				},

				{
					"magnitudeValue": 85.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T21:00:00Z",
					"type": "Point",
					"coordinates": [-91.5, 29.2]
				},

				{
					"magnitudeValue": 60.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T03:00:00Z",
					"type": "Point",
					"coordinates": [-90.6, 30.2]
				},

				{
					"magnitudeValue": 40.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T09:00:00Z",
					"type": "Point",
					"coordinates": [90.1, 30.9]
				},

				{
					"magnitudeValue": 30.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T15:00:00Z",
					"type": "Point",
					"coordinates": [-90.1, 32.5]
				},

				{
					"magnitudeValue": 20.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T21:00:00Z",
					"type": "Point",
					"coordinates": [-89.8, 33.8]
				},

				{
					"magnitudeValue": 25.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T03:00:00Z",
					"type": "Point",
					"coordinates": [-90.9, 35.2]
				},

				{
					"magnitudeValue": 20.00,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T09:00:00Z",
					"type": "Point",
					"coordinates": [-91.5, 35.5]
				}


			]
		},

		{
			"id": "EONET_10930",
			"title": "Wildfire in Angola 1022024",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10930",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022024"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [14.286341412809493, -15.344682230556121]
				}


			]
		},
		{
			"id": "EONET_10931",
			"title": "Wildfire in Brazil 1022028",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10931",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022028"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-54.066778593847886, -14.648879896925301]
				}


			]
		},

		{
			"id": "EONET_10932",
			"title": "Wildfire in Angola 1022025",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10932",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022025"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [17.989166513464152, -16.542345956633447]
				}


			]
		},

		{
			"id": "EONET_10933",
			"title": "Wildfire in Mozambique 1022026",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10933",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022026"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [37.76508433647011, -12.600050090282926]
				}


			]
		},

		{
			"id": "EONET_10934",
			"title": "Wildfire in Australia 1022114",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10934",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022114"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [136.44075426861289, -16.084652839276654]
				}


			]
		},

		{
			"id": "EONET_10935",
			"title": "Wildfire in Paraguay 1022109",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10935",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022109"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-56.294401849932079, -22.299721303713582]
				}


			]
		},

		{
			"id": "EONET_10936",
			"title": "Wildfire in Brazil 1022110",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10936",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022110"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-47.077098687340339, -12.871301937652298]
				}


			]
		},

		{
			"id": "EONET_10937",
			"title": "Wildfire in Brazil 1022111",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10937",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022111"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.236058612138272, -10.118758807618548]
				}


			]
		},

		{
			"id": "EONET_10938",
			"title": "Wildfire in Brazil 1022023",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10938",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022023"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-56.48398514420942, -15.861942123384669]
				}


			]
		},

		{
			"id": "EONET_10939",
			"title": "Wildfire in Australia 1022027",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10939",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022027"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [127.6769428745573, -18.470404074411817]
				}


			]
		},

		{
			"id": "EONET_10940",
			"title": "Wildfire in Brazil 1022029",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10940",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022029"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-46.6050445334142, -6.9134651740493807]
				}


			]
		},

		{
			"id": "EONET_10941",
			"title": "Wildfire in Brazil 1022030",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10941",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022030"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-52.97184247297659, -18.399566118098075]
				}


			]
		},

		{
			"id": "EONET_10942",
			"title": "Wildfire in Brazil 1022031",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10942",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022031"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-48.033130918173207, -22.065828373143937]
				}


			]
		},

		{
			"id": "EONET_10943",
			"title": "Wildfire in Brazil 1022032",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10943",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022032"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-55.367212485680867, -16.099641969590206]
				}


			]
		},

		{
			"id": "EONET_10944",
			"title": "Wildfire in Brazil 1022033",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10944",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022033"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.507421884211055, -18.355565665307424]
				}


			]
		},

		{
			"id": "EONET_10945",
			"title": "Wildfire in Australia 1022034",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10945",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022034"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [131.14082239246335, -15.305925224113144]
				}


			]
		},

		{
			"id": "EONET_10946",
			"title": "Wildfire in Brazil 1022035",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10946",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022035"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-53.904519694390586, -16.650167450898529]
				}


			]
		},

		{
			"id": "EONET_10947",
			"title": "Wildfire in United States 1022036",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10947",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022036"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-117.70155770037337, 34.3116001158924]
				}


			]
		},

		{
			"id": "EONET_10948",
			"title": "Wildfire in Brazil 1022037",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10948",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022037"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-57.964638171498564, -20.216876285676683]
				}


			]
		},

		{
			"id": "EONET_11051",
			"title": "Wildfire in Angola 1022135",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11051",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022135"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [21.585429075895533, -17.712991207037234]
				}


			]
		},

		{
			"id": "EONET_11052",
			"title": "Wildfire in Angola 1022136",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11052",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022136"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [14.424437474901728, -15.345920298426073]
				}


			]
		},

		{
			"id": "EONET_11053",
			"title": "Wildfire in Zambia 1022137",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11053",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022137"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [31.72477462287501, -10.615551632160921]
				}


			]
		},

		{
			"id": "EONET_11054",
			"title": "Wildfire in Brazil 1022154",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11054",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022154"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.87694012713002, -12.979194400687851]
				}


			]
		},

		{
			"id": "EONET_11055",
			"title": "Wildfire in Australia 1022155",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11055",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022155"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [135.3522904690017, -15.392870467399394]
				}


			]
		},

		{
			"id": "EONET_11056",
			"title": "Wildfire in Brazil 1022143",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11056",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022143"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-47.315166548524047, -8.5658561362503622]
				}


			]
		},

		{
			"id": "EONET_11057",
			"title": "Wildfire in Bolivia 1022144",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11057",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022144"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [-64.52988435223746, -12.624892741031202]
				}


			]
		},

		{
			"id": "EONET_11077",
			"title": "Wildfire in Mozambique 1022163",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11077",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022163"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [34.208116670660566, -15.273429333540491]
				}


			]
		},

		{
			"id": "EONET_11078",
			"title": "Wildfire in Tanzania 1022164",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11078",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022164"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-08T19:00:00Z",
					"type": "Point",
					"coordinates": [35.345669457328519, -10.393360152868091]
				}


			]
		},

		{
			"id": "EONET_10899",
			"title": "TABLE Wildfire, Owyhee, Idaho",
			"description": "20 miles south of Bruneau, ID",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10899",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 14000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-08T12:32:00Z",
					"type": "Point",
					"coordinates": [-115.871036, 42.565682]
				}


			]
		},

		{
			"id": "EONET_10898",
			"title": "LITTLE LAVA Wildfire, Deschutes, Oregon",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10898",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 1000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-08T10:49:00Z",
					"type": "Point",
					"coordinates": [-121.727467, 43.895717]
				}


			]
		},

		{
			"id": "EONET_10949",
			"title": "Wildfire in Mozambique 1022102",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10949",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022102"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [35.724582062434379, -13.830756690834363]
				}


			]
		},

		{
			"id": "EONET_10950",
			"title": "Wildfire in Mozambique 1022038",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10950",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022038"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [37.717010450247209, -12.311326134217706]
				}


			]
		},

		{
			"id": "EONET_10951",
			"title": "Wildfire in Angola 1022044",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10951",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022044"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [19.957627596933097, -16.329452354704454]
				}


			]
		},

		{
			"id": "EONET_10952",
			"title": "Wildfire in Mozambique 1022047",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10952",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022047"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [36.934925920485419, -15.12642805575482]
				}


			]
		},

		{
			"id": "EONET_10953",
			"title": "Wildfire in Australia 1022055",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10953",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022055"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [131.87807852972264, -14.82898788736871]
				}


			]
		},

		{
			"id": "EONET_10954",
			"title": "Wildfire in Brazil 1022057",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10954",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022057"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.726890793558724, -17.695001535252395]
				}


			]
		},

		{
			"id": "EONET_10955",
			"title": "Wildfire in Brazil 1022060",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10955",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022060"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-54.4304806151253, -16.205575423729258]
				}


			]
		},

		{
			"id": "EONET_10956",
			"title": "Wildfire in Brazil 1022061",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10956",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022061"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-52.819711777490809, -17.46553693331542]
				}


			]
		},

		{
			"id": "EONET_10957",
			"title": "Wildfire in Brazil 1022039",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10957",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022039"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-49.838673128036866, -18.116348270753136]
				}


			]
		},

		{
			"id": "EONET_10958",
			"title": "Wildfire in Brazil 1022049",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10958",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022049"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.967946251916821, -17.929168459759911]
				}


			]
		},

		{
			"id": "EONET_10959",
			"title": "Wildfire in The Democratic Republic of Congo 1022040",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10959",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022040"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [30.321462605525536, -7.9597215606374867]
				}


			]
		},

		{
			"id": "EONET_10960",
			"title": "Wildfire in Brazil 1022041",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10960",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022041"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-53.525391966222806, -9.7261776672112461]
				}


			]
		},

		{
			"id": "EONET_10961",
			"title": "Wildfire in Australia 1022042",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10961",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022042"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [131.23809821961711, -11.683897586222558]
				}


			]
		},

		{
			"id": "EONET_10962",
			"title": "Wildfire in Brazil 1022043",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10962",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022043"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-45.337058668373075, -11.290554194633625]
				}


			]
		},

		{
			"id": "EONET_10963",
			"title": "Wildfire in Australia 1022045",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10963",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022045"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [133.94064364237198, -14.974755967469461]
				}


			]
		},

		{
			"id": "EONET_10964",
			"title": "Wildfire in Brazil 1022046",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10964",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022046"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-45.343870065589726, -14.637463720513519]
				}


			]
		},

		{
			"id": "EONET_10965",
			"title": "Wildfire in Brazil 1022048",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10965",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022048"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-49.724425993926161, -6.4955744253035217]
				}


			]
		},

		{
			"id": "EONET_10966",
			"title": "Wildfire in Australia 1022050",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10966",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022050"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [141.9223283779603, -15.202511553363763]
				}


			]
		},

		{
			"id": "EONET_10967",
			"title": "Wildfire in Brazil 1022051",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10967",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022051"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-52.858844295293324, -17.602681445942824]
				}


			]
		},

		{
			"id": "EONET_10968",
			"title": "Wildfire in Namibia 1022052",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10968",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022052"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [20.720385836737403, -18.14477003302531]
				}


			]
		},

		{
			"id": "EONET_10969",
			"title": "Wildfire in Australia 1022053",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10969",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022053"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [130.70990494755426, -17.911136965208328]
				}


			]
		},

		{
			"id": "EONET_10970",
			"title": "Wildfire in Brazil 1022054",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10970",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022054"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-48.810708104851784, -9.2130304366210467]
				}


			]
		},

		{
			"id": "EONET_10971",
			"title": "Wildfire in Brazil 1022056",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10971",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022056"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-51.984872134201851, -17.503937366602752]
				}


			]
		},

		{
			"id": "EONET_10972",
			"title": "Wildfire in Brazil 1022058",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10972",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022058"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-57.372564853565855, -14.83806154300671]
				}


			]
		},

		{
			"id": "EONET_10973",
			"title": "Wildfire in Brazil 1022059",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10973",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022059"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.022379563253224, -8.90561788611075]
				}


			]
		},

		{
			"id": "EONET_10974",
			"title": "Wildfire in Zambia 1022062",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10974",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022062"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [30.650732309388292, -10.986859817238718]
				}


			]
		},

		{
			"id": "EONET_10975",
			"title": "Wildfire in Australia 1022063",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10975",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022063"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [131.53250288610781, -13.868351232435533]
				}


			]
		},

		{
			"id": "EONET_10976",
			"title": "Wildfire in Brazil 1022064",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10976",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022064"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-53.594061329919029, -17.755267709841629]
				}


			]
		},
		{
			"id": "EONET_10977",
			"title": "Wildfire in Brazil 1022065",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10977",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022065"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.82543478813043, -12.554980784946473]
				}


			]
		},

		{
			"id": "EONET_10978",
			"title": "Wildfire in Brazil 1022066",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10978",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022066"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-55.378973274606949, -14.351791735514436]
				}


			]
		},

		{
			"id": "EONET_10979",
			"title": "Wildfire in Brazil 1022112",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10979",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022112"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.196728124616207, -10.795201879117279]
				}


			]
		},

		{
			"id": "EONET_10980",
			"title": "Wildfire in Brazil 1022123",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10980",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022123"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-56.572712772657141, -14.544945619690893]
				}


			]
		},

		{
			"id": "EONET_10981",
			"title": "Wildfire in Brazil 1022124",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10981",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022124"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-50.292946136624479, -8.6812430411748487]
				}


			]
		},

		{
			"id": "EONET_10982",
			"title": "Wildfire in Brazil 1022115",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10982",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022115"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [-55.115694040374926, -19.338551905442067]
				}


			]
		},

		{
			"id": "EONET_11058",
			"title": "Wildfire in Mozambique 1022138",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_11058",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022138"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-07T19:00:00Z",
					"type": "Point",
					"coordinates": [38.234841937161484, -14.778240235354726]
				}


			]
		},

		{
			"id": "EONET_10893",
			"title": "ROBLAR Wildfire, San Diego, California",
			"description": "8 MILES WEST OF FALLBROOK, CA",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10893",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 950.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T17:56:00Z",
					"type": "Point",
					"coordinates": [-117.351694, 33.387036]
				}


			]
		},

		{
			"id": "EONET_10894",
			"title": "Davis Wildfire, Washoe, Nevada",
			"description": "The fire is 1 mile south of Reno, burning south of SR 431 and west of  I -580.",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10894",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 5000.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T17:53:00Z",
					"type": "Point",
					"coordinates": [-119.8275, 39.305]
				}


			]
		},

		{
			"id": "EONET_10889",
			"title": "Frog Wildfire, Custer, Idaho",
			"description": "Little Boulder Creek off the East Fork of the Salmon River",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10889",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 1500.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T16:24:00Z",
					"type": "Point",
					"coordinates": [-114.525667, 44.082833]
				}


			]
		},

		{
			"id": "EONET_10887",
			"title": "Linton Creek Wildfire, Lane, Oregon",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10887",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 728.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T16:23:00Z",
					"type": "Point",
					"coordinates": [-121.842633, 44.144217]
				}


			]
		},

		{
			"id": "EONET_10895",
			"title": "Buck Creek Wildfire, Lake, Oregon",
			"description": "30 miles SW of Silver Lake in the Yamsi semi primitive area",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10895",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 2200.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T12:17:00Z",
					"type": "Point",
					"coordinates": [-121.293167, 42.976667]
				}


			]
		},

		{
			"id": "EONET_10888",
			"title": "FIRESTONE Wildfire, Deschutes, Oregon",
			"description": "21 miles N of Fort Rock, OR",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10888",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 6500.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T11:12:00Z",
					"type": "Point",
					"coordinates": [-120.972091, 43.637322]
				}


			]
		},

		{
			"id": "EONET_10890",
			"title": "FLAT TOP Wildfire, Lake, Oregon",
			"description": "10 Miles N of Fort Rock, OR",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10890",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 13680.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T10:53:00Z",
					"type": "Point",
					"coordinates": [-121.102133, 43.49705]
				}


			]
		},

		{
			"id": "EONET_10896",
			"title": "Bowman Well Wildfire, Lake, Oregon",
			"description": "In the town of Christmas Valley",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10896",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 2867.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-07T00:37:00Z",
					"type": "Point",
					"coordinates": [-120.737117, 43.295883]
				}


			]
		},

		{
			"id": "EONET_10886",
			"title": "SERVICE Wildfire, Wheeler, Oregon",
			"description": "10.2 MILES EAST OF FOSSIL, OR",
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10886",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}


			],
			"geometry": [
				{
					"magnitudeValue": 15015.00,
					"magnitudeUnit": "acres",
					"date": "2024-09-06T20:04:00Z",
					"type": "Point",
					"coordinates": [-120.058147, 44.90148]
				}


			]
		},

		{
			"id": "EONET_10983",
			"title": "Wildfire in Paraguay 1022067",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10983",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022067"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-06T19:00:00Z",
					"type": "Point",
					"coordinates": [-57.582680664305528, -23.696940579377351]
				}


			]
		},

		{
			"id": "EONET_10984",
			"title": "Wildfire in Angola 1022068",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10984",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022068"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-06T19:00:00Z",
					"type": "Point",
					"coordinates": [19.237861080897961, -17.598136686410562]
				}


			]
		},

		{
			"id": "EONET_10985",
			"title": "Wildfire in Mozambique 1022086",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10985",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}

			],
			"sources": [
				{
					"id": "GDACS",
					"url": "https://www.gdacs.org/report.aspx?eventtype=WF&amp;eventid=1022086"
				}


			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-09-06T19:00:00Z",
					"type": "Point",
					"coordinates": [36.986723863065386, -12.304968808724986]
				}


			]
		},

		{
			"id": "EONET_10212",
			"title": "Iceberg B22F",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10212",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 330,
					"magnitudeUnit": "NM^2",
					"date": "2024-08-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-127.41,
						-72.61
					]
				}
			]
		},
		{
			"id": "EONET_10213",
			"title": "Iceberg B22G",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10213",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 45,
					"magnitudeUnit": "NM^2",
					"date": "2024-08-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-127.08,
						-72.46
					]
				}
			]
		},
		{
			"id": "EONET_10631",
			"title": "Sheveluch Volcano, Russia",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10631",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=300270"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-08-17T00:00:00Z",
					"type": "Point",
					"coordinates": [
						161.36,
						56.653
					]
				}
			]
		},
		{
			"id": "EONET_10098",
			"title": "Whakaari/White Island",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10098",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=241040"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-08-09T00:00:00Z",
					"type": "Point",
					"coordinates": [
						177.18,
						37.52
					]
				}
			]
		},
		{
			"id": "EONET_9679",
			"title": "Suwanosejima Volcano, Japan",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_9679",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=282030"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-08-02T00:00:00Z",
					"type": "Point",
					"coordinates": [
						129.714,
						29.638
					]
				}
			]
		},
		{
			"id": "EONET_10148",
			"title": "Nyamulagira Volcano, DR Congo",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10148",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=223020"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-07-30T00:00:00Z",
					"type": "Point",
					"coordinates": [
						29.2,
						-1.408
					]
				}
			]
		},
		{
			"id": "EONET_10147",
			"title": "Bezymianny Volcano, Russia",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10147",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=300250"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-07-24T00:00:00Z",
					"type": "Point",
					"coordinates": [
						160.595,
						55.972
					]
				}
			]
		},
		{
			"id": "EONET_8708",
			"title": "Erta Ale, Ethiopia",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_8708",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=221080"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-07-01T00:00:00Z",
					"type": "Point",
					"coordinates": [
						40.666,
						13.601
					]
				}
			]
		},
		{
			"id": "EONET_8586",
			"title": "Ambae Volcano, Vanuatu",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_8586",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=257030"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-06-29T00:00:00Z",
					"type": "Point",
					"coordinates": [
						167.835,
						-15.398
					]
				}
			]
		},
		{
			"id": "EONET_8588",
			"title": "Karymsky Volcano, Russia",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_8588",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=300130"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-06-20T00:00:00Z",
					"type": "Point",
					"coordinates": [
						159.443,
						54.049
					]
				}
			]
		},
		{
			"id": "EONET_8455",
			"title": "Home Reef Volcano, Tonga",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_8455",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "EO",
					"url": "https://earthobservatory.nasa.gov/images/153003/home-reef-volcano-grows"
				},
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=243080"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-06-18T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-174.775,
						-18.992
					]
				}
			]
		},
		{
			"id": "EONET_8587",
			"title": "Etna Volcano, Italy",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_8587",
			"closed": null,
			"categories": [
				{
					"id": "volcanoes",
					"title": "Volcanoes"
				}
			],
			"sources": [
				{
					"id": "SIVolcano",
					"url": "https://volcano.si.edu/volcano.cfm?vn=211060"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-06-06T00:00:00Z",
					"type": "Point",
					"coordinates": [
						14.999,
						37.748
					]
				}
			]
		},
		{
			"id": "EONET_10885",
			"title": "Tropical Storm Francine",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_10885",
			"closed": null,
			"categories": [
				{
					"id": "severeStorms",
					"title": "Severe Storms"
				}
			],
			"sources": [
				{
					"id": "NOAA_NHC",
					"url": "https://www.nhc.noaa.gov/archive/2024/FRANCINE.shtml"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 45,
					"magnitudeUnit": "kts",
					"date": "2024-09-09T15:00:00Z",
					"type": "Point",
					"coordinates": [
						-94.9,
						23
					]
				},
				{
					"magnitudeValue": 55,
					"magnitudeUnit": "kts",
					"date": "2024-09-09T21:00:00Z",
					"type": "Point",
					"coordinates": [
						-96,
						24
					]
				},
				{
					"magnitudeValue": 55,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T03:00:00Z",
					"type": "Point",
					"coordinates": [
						-96.2,
						24.3
					]
				},
				{
					"magnitudeValue": 55,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T09:00:00Z",
					"type": "Point",
					"coordinates": [
						-96.2,
						24.4
					]
				},
				{
					"magnitudeValue": 55,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T15:00:00Z",
					"type": "Point",
					"coordinates": [
						-95.6,
						24.9
					]
				},
				{
					"magnitudeValue": 55,
					"magnitudeUnit": "kts",
					"date": "2024-09-10T21:00:00Z",
					"type": "Point",
					"coordinates": [
						-95,
						25.7
					]
				},
				{
					"magnitudeValue": 65,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T03:00:00Z",
					"type": "Point",
					"coordinates": [
						-94.3,
						26.4
					]
				},
				{
					"magnitudeValue": 80,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T09:00:00Z",
					"type": "Point",
					"coordinates": [
						-93.8,
						27
					]
				},
				{
					"magnitudeValue": 80,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T15:00:00Z",
					"type": "Point",
					"coordinates": [
						-92.7,
						28
					]
				},
				{
					"magnitudeValue": 85,
					"magnitudeUnit": "kts",
					"date": "2024-09-11T21:00:00Z",
					"type": "Point",
					"coordinates": [
						-91.5,
						29.2
					]
				},
				{
					"magnitudeValue": 60,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T03:00:00Z",
					"type": "Point",
					"coordinates": [
						-90.6,
						30.2
					]
				},
				{
					"magnitudeValue": 40,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T09:00:00Z",
					"type": "Point",
					"coordinates": [
						90.1,
						30.9
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T15:00:00Z",
					"type": "Point",
					"coordinates": [
						-90.1,
						32.5
					]
				},
				{
					"magnitudeValue": 20,
					"magnitudeUnit": "kts",
					"date": "2024-09-12T21:00:00Z",
					"type": "Point",
					"coordinates": [
						-89.8,
						33.8
					]
				},
				{
					"magnitudeValue": 25,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T03:00:00Z",
					"type": "Point",
					"coordinates": [
						-90.9,
						35.2
					]
				},
				{
					"magnitudeValue": 20,
					"magnitudeUnit": "kts",
					"date": "2024-09-13T09:00:00Z",
					"type": "Point",
					"coordinates": [
						-91.5,
						35.5
					]
				}
			]
		},
		{
			"id": "EONET_7412",
			"title": "Thunderstorm Wildfire, Iron, Wisconsin",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_7412",
			"closed": null,
			"categories": [
				{
					"id": "wildfires",
					"title": "Wildfires"
				}
			],
			"sources": [
				{
					"id": "IRWIN",
					"url": "https://irwin.doi.gov/observer/"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 0.01,
					"magnitudeUnit": "acres",
					"date": "2024-06-04T17:27:00Z",
					"type": "Point",
					"coordinates": [
						-90.1063,
						46.18035
					]
				}
			]
		},
		{
			"id": "EONET_6523",
			"title": "Iceberg A83",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6523",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "EO",
					"url": "https://earthobservatory.nasa.gov/images/152848/antarctic-ice-shelf-spawns-iceberg-a-83"
				},
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 140,
					"magnitudeUnit": "NM^2",
					"date": "2024-05-24T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-25.55,
						-75.37
					]
				}
			]
		},
		{
			"id": "EONET_6520",
			"title": "Iceberg A76N",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6520",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 48,
					"magnitudeUnit": "NM^2",
					"date": "2024-05-17T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-54.04,
						-63.76
					]
				}
			]
		},
		{
			"id": "EONET_6510",
			"title": "Iceberg D33C",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6510",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": null,
					"magnitudeUnit": null,
					"date": "2024-04-19T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-20.02,
						-75.52
					]
				}
			]
		},
		{
			"id": "EONET_6482",
			"title": "Iceberg D36",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6482",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 55,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						86.63,
						-66.31
					]
				}
			]
		},
		{
			"id": "EONET_6474",
			"title": "Iceberg D35",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6474",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-01-11T00:00:00Z",
					"type": "Point",
					"coordinates": [
						21.01,
						-69.83
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-01-18T00:00:00Z",
					"type": "Point",
					"coordinates": [
						18.24,
						-69.29
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-02T00:00:00Z",
					"type": "Point",
					"coordinates": [
						16.63,
						-69.53
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-01T00:00:00Z",
					"type": "Point",
					"coordinates": [
						12.63,
						-69.36
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-07T00:00:00Z",
					"type": "Point",
					"coordinates": [
						11.39,
						-69.55
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						6.81,
						-69.77
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-22T00:00:00Z",
					"type": "Point",
					"coordinates": [
						12.63,
						-69.36
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-29T00:00:00Z",
					"type": "Point",
					"coordinates": [
						2.31,
						-69.95
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-04-05T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-1.79,
						-69.69
					]
				},
				{
					"magnitudeValue": 168,
					"magnitudeUnit": "NM^2",
					"date": "2024-04-12T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-5.22,
						-70.01
					]
				}
			]
		},
		{
			"id": "EONET_6465",
			"title": "Iceberg A82",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6465",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-72.42,
						-72.85
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-01-25T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-80.49,
						-72.73
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-02T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-82.76,
						-73.37
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-85.62,
						-72.77
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-16T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-87.87,
						-72.67
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-23T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-89.05,
						-72.37
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-01T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-90.34,
						-71.7
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-91.87,
						-71.94
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-22T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-90.34,
						-71.7
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-29T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-93.2,
						-71.9
					]
				},
				{
					"magnitudeValue": 72,
					"magnitudeUnit": "NM^2",
					"date": "2024-04-12T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-94.08,
						-71.27
					]
				}
			]
		},
		{
			"id": "EONET_6448",
			"title": "Iceberg D34",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6448",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 88,
					"magnitudeUnit": "NM^2",
					"date": "2023-10-20T00:00:00Z",
					"type": "Point",
					"coordinates": [
						82.12,
						-67.18
					]
				}
			]
		},
		{
			"id": "EONET_6423",
			"title": "Iceberg D33A",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6423",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						17.14,
						-69.38
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						14.37,
						-69.23
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-22T00:00:00Z",
					"type": "Point",
					"coordinates": [
						13.16,
						-69.37
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-30T00:00:00Z",
					"type": "Point",
					"coordinates": [
						11.84,
						-69.58
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-10-26T00:00:00Z",
					"type": "Point",
					"coordinates": [
						10.18,
						-69.71
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-11-09T00:00:00Z",
					"type": "Point",
					"coordinates": [
						7.25,
						-69.67
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-11-24T00:00:00Z",
					"type": "Point",
					"coordinates": [
						5.51,
						-69.66
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						1.4,
						-69.58
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-0.74,
						-69.4
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-21T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-1.94,
						-69.6
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-28T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-3.64,
						-69.85
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-01-04T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-5.14,
						-70.07
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-01-18T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-8.04,
						-70.06
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-02T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-10.27,
						-70.56
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-16T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-12.94,
						-71.06
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-23T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-14.77,
						-71.49
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-01T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-17.62,
						-72.18
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-07T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-19.7,
						-72.57
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-21.86,
						-73.22
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-22T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-17.62,
						-72.18
					]
				},
				{
					"magnitudeValue": 340,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-29T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-26.96,
						-74.24
					]
				}
			]
		},
		{
			"id": "EONET_6424",
			"title": "Iceberg D33B",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6424",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						18.3,
						-69.64
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						16.6,
						-69.45
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-30T00:00:00Z",
					"type": "Point",
					"coordinates": [
						13.66,
						-69.3
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2023-10-26T00:00:00Z",
					"type": "Point",
					"coordinates": [
						12.22,
						-69.47
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						9.8,
						-69.61
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						8.01,
						-69.68
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-28T00:00:00Z",
					"type": "Point",
					"coordinates": [
						4.38,
						-69.94
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-01-04T00:00:00Z",
					"type": "Point",
					"coordinates": [
						1.94,
						-69.84
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-01-18T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-2.03,
						-69.22
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-3.15,
						-69.6
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-23T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-4.61,
						-70.16
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-01T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-7.49,
						-70.29
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-07T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-9.33,
						-70.4
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-22T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-7.49,
						-70.29
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-29T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-12.77,
						-71.07
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-04-05T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-15.11,
						-71.47
					]
				},
				{
					"magnitudeValue": 252,
					"magnitudeUnit": "NM^2",
					"date": "2024-04-12T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-16.64,
						-72.06
					]
				}
			]
		},
		{
			"id": "EONET_6330",
			"title": "Iceberg A80D",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6330",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 35,
					"magnitudeUnit": "NM^2",
					"date": "2023-02-23T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.34,
						-72.19
					]
				},
				{
					"magnitudeValue": 35,
					"magnitudeUnit": "NM^2",
					"date": "2023-03-31T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.65,
						-71.62
					]
				},
				{
					"magnitudeValue": 35,
					"magnitudeUnit": "NM^2",
					"date": "2023-04-14T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.75,
						-71.11
					]
				},
				{
					"magnitudeValue": 35,
					"magnitudeUnit": "NM^2",
					"date": "2023-04-28T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.64,
						-70.53
					]
				},
				{
					"magnitudeValue": 35,
					"magnitudeUnit": "NM^2",
					"date": "2023-05-12T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.71,
						-69.34
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-06-09T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.43,
						-68.69
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-06-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.32,
						-68.2
					]
				},
				{
					"magnitudeValue": 35,
					"magnitudeUnit": "NM^2",
					"date": "2023-06-23T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.44,
						-69.02
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-06-30T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.09,
						-67.56
					]
				},
				{
					"magnitudeValue": 35,
					"magnitudeUnit": "NM^2",
					"date": "2023-07-28T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-59.44,
						-69.02
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-08-04T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-58.84,
						-66.76
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-01T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-57.34,
						-66.6
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-08T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-57.84,
						-66.19
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-10-13T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-57.82,
						-65.69
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-11-24T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-56.73,
						-65.59
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2023-12-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-56.13,
						-65.09
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2024-02-16T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-56.85,
						-65.46
					]
				},
				{
					"magnitudeValue": 30,
					"magnitudeUnit": "NM^2",
					"date": "2024-04-12T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-56.07,
						-64.85
					]
				}
			]
		},
		{
			"id": "EONET_6320",
			"title": "Iceberg A81",
			"description": null,
			"link": "https://eonet.gsfc.nasa.gov/api/v3/events/EONET_6320",
			"closed": null,
			"categories": [
				{
					"id": "seaLakeIce",
					"title": "Sea and Lake Ice"
				}
			],
			"sources": [
				{
					"id": "NATICE",
					"url": "https://usicecenter.gov/pub/Iceberg_Tabular.csv"
				}
			],
			"geometry": [
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-01-27T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-27.16,
						-75.66
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-02-24T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-28.83,
						-76.01
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-03-10T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-30.79,
						-76.37
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-03-31T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-33.68,
						-76.8
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-04-07T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-34.92,
						-77.18
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-04-28T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-36.06,
						-77.59
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-05-26T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-38.53,
						-77.69
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-06-15T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-40.51,
						-77.54
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-07-14T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-42.95,
						-77.38
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-07-28T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-39.22,
						-77.69
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-08-04T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-44.49,
						-77.08
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-09-22T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-45.63,
						-76.69
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2023-10-26T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-48.51,
						-76.47
					]
				},
				{
					"magnitudeValue": 700,
					"magnitudeUnit": "NM^2",
					"date": "2024-03-07T00:00:00Z",
					"type": "Point",
					"coordinates": [
						-47.68,
						-75.98
					]
				}
			]
		},


	];




	const eventosLayerGroup = L.layerGroup().addTo(map);

	const iconos = {
		"wildfires": L.icon({
			iconUrl: './icons/incendio.png',
			iconSize: [24, 24],
			iconAnchor: [12, 24],
			popupAnchor: [0, -32]
		}),
		"severeStorms": L.icon({
			iconUrl: './icons/nube.png',
			iconSize: [24, 24],
			iconAnchor: [12, 24],
			popupAnchor: [0, -32]
		}),
		"seaLakeIce": L.icon({
			iconUrl: './icons/iceberg.png',
			iconSize: [24, 24],
			iconAnchor: [12, 24],
			popupAnchor: [0, -32]
		}),
		"volcanoes": L.icon({
			iconUrl: './icons/volcano.png',
			iconSize: [24, 24],
			iconAnchor: [12, 24],
			popupAnchor: [0, -32]
		}),
	};


	eventos.forEach(evento => {
		if (evento.geometry && evento.geometry.length > 0 && evento.geometry[0].coordinates) {
			const coordinates = evento.geometry[0].coordinates;
			const lat = coordinates[1];
			const lon = coordinates[0];
			const categoryId = evento.categories[0]?.id || 'default';

			const marker = L.marker([lat, lon], { icon: iconos[categoryId] || iconos['default'] }).addTo(eventosLayerGroup);
			marker.bindPopup(`
                <b>${evento.title}</b><br>
                <a href="#" data-event-id="${evento.id}" class="event-link">More info</a>
            `);

			marker.on('click', function () {
				displayEventDetails(evento);
			});
		} else {
			console.warn('Evento con coordenadas inválidas:', evento);
		}
	});

	const baseMaps = {
		"OpenStreetMap": L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
		})
	};

	const overlays = {
		"Eventos": eventosLayerGroup
	};

	L.control.layers(baseMaps, overlays).addTo(map);

	function displayEventDetails(evento) {
		const eventDetails = document.getElementById('event-details');
		eventDetails.innerHTML = `
        <h3>${evento.title}</h3>
        <p>${evento.description || 'No description available'}</p>
        <p><strong>Date:</strong> ${evento.geometry[0].date}</p>
        <p><strong>Categories:</strong> ${evento.categories.map(cat => cat.title).join(', ')}</p>
        <p><strong>Sources:</strong> ${evento.sources.map(source => `<a href="${source.url}" target="_blank">${source.id}</a>`).join(', ')}</p>
        <p><a href="${evento.link}" target="_blank">More info</a></p>
    `;
	}
});