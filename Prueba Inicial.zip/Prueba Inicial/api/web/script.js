document.addEventListener('DOMContentLoaded', function () {
    // Crear el mapa 
    const map = L.map('map').setView([0, 0], 2);

    // capas base
    const openStreetMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    });

    const openTopoMap = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://opentopomap.org">OpenTopoMap</a> contributors'
    });

    const esriWorldImagery = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri &mdash; Source: Esri, USGS, NOAA'
    });

    const stadiaMap = L.tileLayer('https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a>'
    });

    // OpenStreetMap como capa base 
    openStreetMap.addTo(map);

    // Crear eventos
    const eventosLayerGroup = L.layerGroup().addTo(map);

    const iconos = {
        "wildfires": L.icon({
            iconUrl: './icons/incendio.png',
            iconSize: [24, 24],
            iconAnchor: [12, 24],
            popupAnchor: [0, -24]
        }),
        "severeStorms": L.icon({
            iconUrl: './icons/nube.png',
            iconSize: [24, 24],
            iconAnchor: [12, 24],
            popupAnchor: [0, -24]
        }),
        "volcanoes": L.icon({
            iconUrl: './icons/volcano.png',
            iconSize: [24, 24],
            iconAnchor: [12, 24],
            popupAnchor: [0, -24]
        }),
        "seaLakeIce": L.icon({
            iconUrl: './icons/iceberg.png',
            iconSize: [24, 24],
            iconAnchor: [12, 24],
            popupAnchor: [0, -24]
        })
    };

    // Función para mostrar los eventos en el mapa
    function mostrarEventos(eventos) {
        eventosLayerGroup.clearLayers(); 
        eventos.forEach(evento => {
            if (evento.geometry && evento.geometry.length > 0 && evento.geometry[0].coordinates) {
                const coordinates = evento.geometry[0].coordinates;
                const lat = coordinates[1];
                const lon = coordinates[0];
                const categoryId = evento.categories[0]?.id || 'default';

                const marker = L.marker([lat, lon], { icon: iconos[categoryId] || iconos['default'] }).addTo(eventosLayerGroup);
                marker.bindPopup(`
                    <b>${evento.title}</b><br>
                    <a href="#" data-event-id="${evento.id}" class="event-link">More info</a>
                    <div id="weather-${evento.id}"></div> <!-- Div para el clima -->
                `);

                marker.on('click', function () {
                    displayEventDetails(evento);
                    getWeather(lat, lon, evento.id); 
                });
            }
        });
    }

    // Función para mostrar los detalles de un evento en la sidebar
    function displayEventDetails(evento) {
        const eventDetails = document.getElementById('event-details');
        eventDetails.innerHTML = `
            <h3>${evento.title}</h3>
            <p>${evento.description || 'No description available'}</p>
            <p><strong>Date:</strong> ${evento.geometry[0].date}</p>
            <p><strong>Categories:</strong> ${evento.categories.map(cat => cat.title).join(', ')}</p>
            <p><strong>Sources:</strong> ${evento.sources.map(source => `<a href="${source.url}" target="_blank">${source.id}</a>`).join(', ')}</p>
            <p><a href="${evento.link}" target="_blank">More info</a></p>
        `;
        const weatherInfo = document.getElementById('weather-info');
        weatherInfo.innerHTML = ''; 
    }

// Función para obtener el clima
function getWeather(lat, lon, eventId) {
    const apiKey = 'f57d9073d3b689222507471343dc8d9c'; 

    fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`)
        .then(response => response.json())
        .then(data => {
            const weatherInfo = `
                <p><strong>Weather:</strong> ${data.weather[0].description}</p>
                <p><strong>Temperature:</strong> ${data.main.temp} °C</p>
            `;
            document.getElementById(`weather-${eventId}`).innerHTML = weatherInfo; 

            
            const weatherSidebar = document.getElementById('weather-info');
            weatherSidebar.innerHTML = weatherInfo; 
        })
        .catch(error => {
            console.error('Error al obtener el clima:', error);
        });
}

    // Hacer la solicitud a la API de EONET
    fetch('https://eonet.gsfc.nasa.gov/api/v3/events')
        .then(response => response.json())
        .then(data => {
            const eventos = data.events;
            mostrarEventos(eventos);
        })
        .catch(error => {
            console.error('Error al obtener los eventos:', error);
        });

 // Filtro de eventos por rango de fechas
 document.getElementById('filter-btn').addEventListener('click', function () {
    const startDate = new Date(document.getElementById('start-date').value);
    const endDate = new Date(document.getElementById('end-date').value);

    if (isNaN(startDate) || isNaN(endDate)) {
        alert('Por favor, selecciona un rango de fechas válido.');
        return;
    }

    fetch('https://eonet.gsfc.nasa.gov/api/v3/events')
        .then(response => response.json())
        .then(data => {
            const eventosFiltrados = data.events.filter(evento => {
                const eventDate = new Date(evento.geometry[0].date);
                return eventDate >= startDate && eventDate <= endDate;
            });
            mostrarEventos(eventosFiltrados);
        })
        .catch(error => {
            console.error('Error al obtener los eventos filtrados:', error);
        });
});

// Botón para limpiar el filtro
document.getElementById('clear-filter-btn').addEventListener('click', function () {

    document.getElementById('start-date').value = '';
    document.getElementById('end-date').value = '';


    fetch('https://eonet.gsfc.nasa.gov/api/v3/events')
        .then(response => response.json())
        .then(data => {
            const eventos = data.events;
            mostrarEventos(eventos);
        })
        .catch(error => {
            console.error('Error al obtener todos los eventos:', error);
        });
});
 // Alternar entre las capas base
 const capasBase = {
    "OpenStreetMap": openStreetMap,
    "OpenTopoMap": openTopoMap,
    "Esri World Imagery": esriWorldImagery,
    "Stadia Maps": stadiaMap
};

L.control.layers(capasBase).addTo(map);
});
