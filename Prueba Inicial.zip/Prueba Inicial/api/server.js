const express = require('express');
const path = require('path');

const app = express();
const port = 3000;

// Servir archivos estáticos desde la carpeta 'web'
app.use(express.static(path.join(__dirname, 'web')));

// Ruta para servir el archivo HTML principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'web', 'index.html'));
});


// Iniciar el servidor en el puerto 3000
app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});
