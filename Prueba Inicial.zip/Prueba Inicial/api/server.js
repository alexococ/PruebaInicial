const express = require('express');
const path = require('path'); // Módulo para gestionar rutas de archivos

const app = express();
const port = 3000;


// Servir archivos estáticos desde la carpeta "web"
app.use(express.static(path.join(__dirname, 'web')));

// Ruta para servir el archivo index.html en la ruta raíz "/"
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'web', 'index.html'));
});
// Ruta para obtener todos los eventos
app.get('/api/eventos', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM eventos');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Error al obtener los eventos');
    }
});

// Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});
